var Website = angular.module('Website', []);

Website.config(['$routeProvider',
    function($routeProvider) {
        $routeProvider.
            when('/Home', {templateUrl: 'templates/Home.html', controller: 'HomeController'}).
            when('/About', {templateUrl: 'templates/About.html', controller: 'AboutController'});

    }]);

Website.controller('HomeController', function($scope) {

    $scope.message = 'This website gives you the ability to add two numbers'; });

Website.controller('AboutController', function($scope) {

    $scope.message = 'This page has all the About Us details';});


Website.controller('MainCtrl', function($scope) {
    $scope.add=function(num1,num2)
    {$scope.result=parseInt(num1)+parseInt(num2);
    }
});
